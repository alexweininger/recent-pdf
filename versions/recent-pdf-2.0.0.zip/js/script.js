/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/script.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/script.ts":
/*!***********************!*\
  !*** ./src/script.ts ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/// <reference path='../node_modules/@types/chrome/index.d.ts'/>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let onlineList = document.getElementById('link-list'); // online file list
let fileElement = document.getElementById('file-list'); // offline (local) file list
let onlineTabLink = document.getElementById('online-tab-link');
let localTabLink = document.getElementById('local-tab-link');
let settingsTabLink = document.getElementById('settings-link');
let currentTab;
var Tab;
(function (Tab) {
    Tab["Local"] = "local";
    Tab["Online"] = "online";
})(Tab || (Tab = {}));
// tab buttons
if (onlineTabLink) {
    // event handlers for tab buttons
    onlineTabLink.addEventListener('click', function (event) {
        onlineFooter(onlinePdfCount);
        openTab(event, Tab.Online);
        currentTab = Tab.Online;
    });
}
else {
    console.error('onlineTabLink is null');
}
// click listener for local pdf tab
if (localTabLink) {
    localTabLink.addEventListener('click', function (event) {
        localFooter(localPdfCount);
        openTab(event, Tab.Local);
        currentTab = Tab.Local;
    });
}
else {
    console.error('localTabLink is null');
}
// settings click listener
settingsTabLink.addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
});
searchHistory();
searchDownloads();
let onlinePdfCount = 0; // number of online pdf files
/**
 * searchHistory() - searches history using the chrome.history api for online pdf files
 */
function searchHistory() {
    chrome.history.search({
        text: '.pdf',
        maxResults: 10000
    }, function (data) {
        data.forEach(function (page) {
            // for each result
            if (page.url.endsWith('.pdf') || page.url.endsWith('.PDF')) {
                // check if page is a .pdf
                let listItem = document.createElement('li');
                listItem.classList.add('list-item');
                if (!page.url.startsWith('file:')) {
                    // if not local pdf
                    onlinePdfCount++;
                    let leftDiv = document.createElement('div');
                    let rightDiv = document.createElement('div');
                    leftDiv.classList.add('list-div', 'left');
                    rightDiv.classList.add('list-div', 'right');
                    // make title element
                    let title = document.createElement('p');
                    title.classList.add('link-title');
                    title.innerText = decodeURI(page.url).substring(page.url.lastIndexOf('/') + 1, page.url.length - 4);
                    // make url element
                    let linkUrl = document.createElement('p');
                    linkUrl.classList.add('link-url');
                    linkUrl.innerHTML = decodeURI(page.url)
                        .substring(0, 50)
                        .replace(' ', '');
                    // make icon element
                    let icon = document.createElement('img');
                    icon.classList.add('link-thumb');
                    icon.src = `chrome://favicon/${page.url}`;
                    // append elements to left div
                    leftDiv.appendChild(icon);
                    leftDiv.appendChild(title);
                    leftDiv.appendChild(linkUrl);
                    // on click listener
                    leftDiv.addEventListener('click', function () {
                        window.open(page.url);
                    });
                    // append to list item
                    listItem.appendChild(leftDiv);
                    listItem.appendChild(rightDiv);
                    // append list item to online list
                    onlineList.appendChild(listItem);
                }
            }
        });
        console.log(`${onlinePdfCount} online PDFs found.`);
        console.log('hello');
        updateFooter();
    });
}
let localFiles = [];
let localPdfCount = 0; // number of local pdf files
/**
 * searchDownloads() - searches downloads with chrome.downloads api for local pdf files
 */
function searchDownloads() {
    chrome.downloads.search({
        limit: 0,
        orderBy: ['-startTime'],
        filenameRegex: '^(.(.*\.pdf$))*$'
    }, function (data) {
        if (data.length == 0) {
            searchDownloads();
            return;
        }
        console.log('found ' + data.length + ' local pdfs');
        data.forEach(function (file, i) {
            // for each result
            console.log('TCL: searchDownloads -> i', i);
            if (file.filename.endsWith('.pdf') || file.filename.endsWith('.PDF')) {
                // check if file ends with .pdf or .PDF
                if (localFiles.indexOf(file.filename) === -1 && localPdfCount < 30) {
                    // check for duplicated and max of 30 files
                    localFiles.push(file.filename);
                    localPdfCount++;
                    let leftDiv = document.createElement('div');
                    let rightDiv = document.createElement('div');
                    leftDiv.classList.add('list-div', 'left');
                    rightDiv.classList.add('list-div', 'right');
                    // create local file list item
                    let fileItem = document.createElement('li');
                    fileItem.classList.add('list-item', 'file-item');
                    // create icon element
                    let icon = document.createElement('img');
                    icon.classList.add('link-thumb');
                    chrome.downloads.getFileIcon(file.id, { size: 16 }, iconUrl => {
                        icon.src = iconUrl;
                    });
                    // create title element
                    let title = document.createElement('p');
                    title.classList.add('link-title');
                    title.classList.add('local-title');
                    title.innerText = file.filename.substring(file.filename.lastIndexOf('\\') + 1, file.filename.length - 4);
                    // create file url element
                    let linkUrl = document.createElement('p');
                    linkUrl.classList.add('link-url');
                    linkUrl.innerHTML = file.filename.substring(0, 50);
                    // append elements to div
                    leftDiv.appendChild(icon);
                    leftDiv.appendChild(title);
                    leftDiv.appendChild(linkUrl);
                    // on click listener
                    leftDiv.addEventListener('click', function () {
                        chrome.downloads.open(file.id);
                    });
                    // open in file explorer button
                    let more = document.createElement('img');
                    more.id = 'more_icon';
                    more.src = '../../assets/More.png';
                    more.addEventListener('click', function () {
                        chrome.downloads.show(file.id);
                    });
                    rightDiv.appendChild(more);
                    fileItem.appendChild(leftDiv);
                    fileItem.appendChild(rightDiv);
                    fileElement.appendChild(fileItem);
                }
                else {
                    // console.log(`[INFO] skipped duplicate file: ${file.filename}.`);
                }
            }
        });
        console.log(`[INFO] ${localPdfCount} local PDFs found.`);
        updateFooter();
    });
}
function updateFooter() {
    if (currentTab == Tab.Local) {
        localFooter(localPdfCount);
    }
    else {
        onlineFooter(onlinePdfCount);
    }
}
// load and create the online pdf footer
function onlineFooter(count) {
    let plural = count > 1 ? 's' : '';
    let countDisplay = document.getElementById('count-display');
    countDisplay.innerHTML = `Showing ${count} online PDF${plural}.`;
}
// load and create the local file footer
function localFooter(count) {
    let plural = count > 1 ? 's' : '';
    let countDisplay = document.getElementById('count-display');
    countDisplay.innerHTML = `Showing ${count} local PDF${plural}.`;
}
// function that handles switching between tabs
function openTab(evt, tab) {
    // Find active elements and remove active class from elements
    const activeElements = document.querySelectorAll('.active');
    activeElements.forEach(function (elem) {
        elem.classList.remove('active');
    });
    // Add active class to tab and pressed button
    const tabContent = document.querySelector(`.tabcontent#${tab}`);
    if (tabContent) {
        tabContent.classList.add('active');
    }
    evt.currentTarget.classList.add('active');
    currentTab = tab;
}
function getOption(name, callback) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield chrome.storage.sync.get([name], (result) => {
            if (result) {
                console.log('getOption', result);
                callback(result);
            }
        });
    });
}
function loadOptions() {
    getOption('general.defaultTab', (result) => {
        let defaultTab = result['general.defaultTab'];
        if (defaultTab) {
            if (defaultTab == 'Online files') {
                onlineTabLink.click();
                console.log('clicked online tab link');
            }
            else if (defaultTab == 'Local files') {
                localTabLink.click();
                console.log('clicked local tab link');
            }
            else {
                localTabLink.click();
                console.log('loaded defaults');
            }
        }
        else {
            localTabLink.click();
        }
    });
}
loadOptions();


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxrREFBMEMsZ0NBQWdDO0FBQzFFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0VBQXdELGtCQUFrQjtBQUMxRTtBQUNBLHlEQUFpRCxjQUFjO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBeUMsaUNBQWlDO0FBQzFFLHdIQUFnSCxtQkFBbUIsRUFBRTtBQUNySTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOzs7QUFHQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDbEZhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLE1BQU0sNkJBQTZCLEVBQUUsWUFBWSxXQUFXLEVBQUU7QUFDakcsa0NBQWtDLE1BQU0saUNBQWlDLEVBQUUsWUFBWSxXQUFXLEVBQUU7QUFDcEcsK0JBQStCLGlFQUFpRSx1QkFBdUIsRUFBRSw0QkFBNEI7QUFDcko7QUFDQSxLQUFLO0FBQ0w7QUFDQSxzREFBc0Q7QUFDdEQsdURBQXVEO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLGtCQUFrQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsU0FBUztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCx1QkFBdUIsZUFBZTtBQUN0QztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsV0FBVztBQUN0RTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUVBQXFFLGNBQWM7QUFDbkY7QUFDQTtBQUNBLFNBQVM7QUFDVCw4QkFBOEIsY0FBYztBQUM1QztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxNQUFNLGFBQWEsT0FBTztBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLE1BQU0sWUFBWSxPQUFPO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsNkRBQTZELElBQUk7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBIiwiZmlsZSI6InNjcmlwdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL3NjcmlwdC50c1wiKTtcbiIsIlwidXNlIHN0cmljdFwiO1xyXG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi9ub2RlX21vZHVsZXMvQHR5cGVzL2Nocm9tZS9pbmRleC5kLnRzJy8+XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZShyZXN1bHQudmFsdWUpOyB9KS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbmxldCBvbmxpbmVMaXN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xpbmstbGlzdCcpOyAvLyBvbmxpbmUgZmlsZSBsaXN0XHJcbmxldCBmaWxlRWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmaWxlLWxpc3QnKTsgLy8gb2ZmbGluZSAobG9jYWwpIGZpbGUgbGlzdFxyXG5sZXQgb25saW5lVGFiTGluayA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdvbmxpbmUtdGFiLWxpbmsnKTtcclxubGV0IGxvY2FsVGFiTGluayA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2NhbC10YWItbGluaycpO1xyXG5sZXQgc2V0dGluZ3NUYWJMaW5rID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NldHRpbmdzLWxpbmsnKTtcclxubGV0IGN1cnJlbnRUYWI7XHJcbnZhciBUYWI7XHJcbihmdW5jdGlvbiAoVGFiKSB7XHJcbiAgICBUYWJbXCJMb2NhbFwiXSA9IFwibG9jYWxcIjtcclxuICAgIFRhYltcIk9ubGluZVwiXSA9IFwib25saW5lXCI7XHJcbn0pKFRhYiB8fCAoVGFiID0ge30pKTtcclxuLy8gdGFiIGJ1dHRvbnNcclxuaWYgKG9ubGluZVRhYkxpbmspIHtcclxuICAgIC8vIGV2ZW50IGhhbmRsZXJzIGZvciB0YWIgYnV0dG9uc1xyXG4gICAgb25saW5lVGFiTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIG9ubGluZUZvb3RlcihvbmxpbmVQZGZDb3VudCk7XHJcbiAgICAgICAgb3BlblRhYihldmVudCwgVGFiLk9ubGluZSk7XHJcbiAgICAgICAgY3VycmVudFRhYiA9IFRhYi5PbmxpbmU7XHJcbiAgICB9KTtcclxufVxyXG5lbHNlIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ29ubGluZVRhYkxpbmsgaXMgbnVsbCcpO1xyXG59XHJcbi8vIGNsaWNrIGxpc3RlbmVyIGZvciBsb2NhbCBwZGYgdGFiXHJcbmlmIChsb2NhbFRhYkxpbmspIHtcclxuICAgIGxvY2FsVGFiTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIGxvY2FsRm9vdGVyKGxvY2FsUGRmQ291bnQpO1xyXG4gICAgICAgIG9wZW5UYWIoZXZlbnQsIFRhYi5Mb2NhbCk7XHJcbiAgICAgICAgY3VycmVudFRhYiA9IFRhYi5Mb2NhbDtcclxuICAgIH0pO1xyXG59XHJcbmVsc2Uge1xyXG4gICAgY29uc29sZS5lcnJvcignbG9jYWxUYWJMaW5rIGlzIG51bGwnKTtcclxufVxyXG4vLyBzZXR0aW5ncyBjbGljayBsaXN0ZW5lclxyXG5zZXR0aW5nc1RhYkxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBjaHJvbWUucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcclxufSk7XHJcbnNlYXJjaEhpc3RvcnkoKTtcclxuc2VhcmNoRG93bmxvYWRzKCk7XHJcbmxldCBvbmxpbmVQZGZDb3VudCA9IDA7IC8vIG51bWJlciBvZiBvbmxpbmUgcGRmIGZpbGVzXHJcbi8qKlxyXG4gKiBzZWFyY2hIaXN0b3J5KCkgLSBzZWFyY2hlcyBoaXN0b3J5IHVzaW5nIHRoZSBjaHJvbWUuaGlzdG9yeSBhcGkgZm9yIG9ubGluZSBwZGYgZmlsZXNcclxuICovXHJcbmZ1bmN0aW9uIHNlYXJjaEhpc3RvcnkoKSB7XHJcbiAgICBjaHJvbWUuaGlzdG9yeS5zZWFyY2goe1xyXG4gICAgICAgIHRleHQ6ICcucGRmJyxcclxuICAgICAgICBtYXhSZXN1bHRzOiAxMDAwMFxyXG4gICAgfSwgZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICBkYXRhLmZvckVhY2goZnVuY3Rpb24gKHBhZ2UpIHtcclxuICAgICAgICAgICAgLy8gZm9yIGVhY2ggcmVzdWx0XHJcbiAgICAgICAgICAgIGlmIChwYWdlLnVybC5lbmRzV2l0aCgnLnBkZicpIHx8IHBhZ2UudXJsLmVuZHNXaXRoKCcuUERGJykpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIHBhZ2UgaXMgYSAucGRmXHJcbiAgICAgICAgICAgICAgICBsZXQgbGlzdEl0ZW0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgICAgICAgICAgICAgbGlzdEl0ZW0uY2xhc3NMaXN0LmFkZCgnbGlzdC1pdGVtJyk7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXBhZ2UudXJsLnN0YXJ0c1dpdGgoJ2ZpbGU6JykpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBpZiBub3QgbG9jYWwgcGRmXHJcbiAgICAgICAgICAgICAgICAgICAgb25saW5lUGRmQ291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbGVmdERpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCByaWdodERpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxlZnREaXYuY2xhc3NMaXN0LmFkZCgnbGlzdC1kaXYnLCAnbGVmdCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0RGl2LmNsYXNzTGlzdC5hZGQoJ2xpc3QtZGl2JywgJ3JpZ2h0Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFrZSB0aXRsZSBlbGVtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlLmNsYXNzTGlzdC5hZGQoJ2xpbmstdGl0bGUnKTtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZS5pbm5lclRleHQgPSBkZWNvZGVVUkkocGFnZS51cmwpLnN1YnN0cmluZyhwYWdlLnVybC5sYXN0SW5kZXhPZignLycpICsgMSwgcGFnZS51cmwubGVuZ3RoIC0gNCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFrZSB1cmwgZWxlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsaW5rVXJsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtVcmwuY2xhc3NMaXN0LmFkZCgnbGluay11cmwnKTtcclxuICAgICAgICAgICAgICAgICAgICBsaW5rVXJsLmlubmVySFRNTCA9IGRlY29kZVVSSShwYWdlLnVybClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnN1YnN0cmluZygwLCA1MClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoJyAnLCAnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFrZSBpY29uIGVsZW1lbnRcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGljb24uY2xhc3NMaXN0LmFkZCgnbGluay10aHVtYicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGljb24uc3JjID0gYGNocm9tZTovL2Zhdmljb24vJHtwYWdlLnVybH1gO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGFwcGVuZCBlbGVtZW50cyB0byBsZWZ0IGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGxlZnREaXYuYXBwZW5kQ2hpbGQoaWNvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdERpdi5hcHBlbmRDaGlsZCh0aXRsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdERpdi5hcHBlbmRDaGlsZChsaW5rVXJsKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBvbiBjbGljayBsaXN0ZW5lclxyXG4gICAgICAgICAgICAgICAgICAgIGxlZnREaXYuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKHBhZ2UudXJsKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBhcHBlbmQgdG8gbGlzdCBpdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbGlzdEl0ZW0uYXBwZW5kQ2hpbGQobGVmdERpdik7XHJcbiAgICAgICAgICAgICAgICAgICAgbGlzdEl0ZW0uYXBwZW5kQ2hpbGQocmlnaHREaXYpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGFwcGVuZCBsaXN0IGl0ZW0gdG8gb25saW5lIGxpc3RcclxuICAgICAgICAgICAgICAgICAgICBvbmxpbmVMaXN0LmFwcGVuZENoaWxkKGxpc3RJdGVtKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGAke29ubGluZVBkZkNvdW50fSBvbmxpbmUgUERGcyBmb3VuZC5gKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnaGVsbG8nKTtcclxuICAgICAgICB1cGRhdGVGb290ZXIoKTtcclxuICAgIH0pO1xyXG59XHJcbmxldCBsb2NhbEZpbGVzID0gW107XHJcbmxldCBsb2NhbFBkZkNvdW50ID0gMDsgLy8gbnVtYmVyIG9mIGxvY2FsIHBkZiBmaWxlc1xyXG4vKipcclxuICogc2VhcmNoRG93bmxvYWRzKCkgLSBzZWFyY2hlcyBkb3dubG9hZHMgd2l0aCBjaHJvbWUuZG93bmxvYWRzIGFwaSBmb3IgbG9jYWwgcGRmIGZpbGVzXHJcbiAqL1xyXG5mdW5jdGlvbiBzZWFyY2hEb3dubG9hZHMoKSB7XHJcbiAgICBjaHJvbWUuZG93bmxvYWRzLnNlYXJjaCh7XHJcbiAgICAgICAgbGltaXQ6IDAsXHJcbiAgICAgICAgb3JkZXJCeTogWyctc3RhcnRUaW1lJ10sXHJcbiAgICAgICAgZmlsZW5hbWVSZWdleDogJ14oLiguKlxcLnBkZiQpKSokJ1xyXG4gICAgfSwgZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICBpZiAoZGF0YS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICBzZWFyY2hEb3dubG9hZHMoKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygnZm91bmQgJyArIGRhdGEubGVuZ3RoICsgJyBsb2NhbCBwZGZzJyk7XHJcbiAgICAgICAgZGF0YS5mb3JFYWNoKGZ1bmN0aW9uIChmaWxlLCBpKSB7XHJcbiAgICAgICAgICAgIC8vIGZvciBlYWNoIHJlc3VsdFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnVENMOiBzZWFyY2hEb3dubG9hZHMgLT4gaScsIGkpO1xyXG4gICAgICAgICAgICBpZiAoZmlsZS5maWxlbmFtZS5lbmRzV2l0aCgnLnBkZicpIHx8IGZpbGUuZmlsZW5hbWUuZW5kc1dpdGgoJy5QREYnKSkge1xyXG4gICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgZmlsZSBlbmRzIHdpdGggLnBkZiBvciAuUERGXHJcbiAgICAgICAgICAgICAgICBpZiAobG9jYWxGaWxlcy5pbmRleE9mKGZpbGUuZmlsZW5hbWUpID09PSAtMSAmJiBsb2NhbFBkZkNvdW50IDwgMzApIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayBmb3IgZHVwbGljYXRlZCBhbmQgbWF4IG9mIDMwIGZpbGVzXHJcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxGaWxlcy5wdXNoKGZpbGUuZmlsZW5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsUGRmQ291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbGVmdERpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCByaWdodERpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxlZnREaXYuY2xhc3NMaXN0LmFkZCgnbGlzdC1kaXYnLCAnbGVmdCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0RGl2LmNsYXNzTGlzdC5hZGQoJ2xpc3QtZGl2JywgJ3JpZ2h0Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY3JlYXRlIGxvY2FsIGZpbGUgbGlzdCBpdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGZpbGVJdGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlSXRlbS5jbGFzc0xpc3QuYWRkKCdsaXN0LWl0ZW0nLCAnZmlsZS1pdGVtJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY3JlYXRlIGljb24gZWxlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbi5jbGFzc0xpc3QuYWRkKCdsaW5rLXRodW1iJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hyb21lLmRvd25sb2Fkcy5nZXRGaWxlSWNvbihmaWxlLmlkLCB7IHNpemU6IDE2IH0sIGljb25VcmwgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uLnNyYyA9IGljb25Vcmw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY3JlYXRlIHRpdGxlIGVsZW1lbnRcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGl0bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGUuY2xhc3NMaXN0LmFkZCgnbGluay10aXRsZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlLmNsYXNzTGlzdC5hZGQoJ2xvY2FsLXRpdGxlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGUuaW5uZXJUZXh0ID0gZmlsZS5maWxlbmFtZS5zdWJzdHJpbmcoZmlsZS5maWxlbmFtZS5sYXN0SW5kZXhPZignXFxcXCcpICsgMSwgZmlsZS5maWxlbmFtZS5sZW5ndGggLSA0KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjcmVhdGUgZmlsZSB1cmwgZWxlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsaW5rVXJsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtVcmwuY2xhc3NMaXN0LmFkZCgnbGluay11cmwnKTtcclxuICAgICAgICAgICAgICAgICAgICBsaW5rVXJsLmlubmVySFRNTCA9IGZpbGUuZmlsZW5hbWUuc3Vic3RyaW5nKDAsIDUwKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBhcHBlbmQgZWxlbWVudHMgdG8gZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdERpdi5hcHBlbmRDaGlsZChpY29uKTtcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0RGl2LmFwcGVuZENoaWxkKHRpdGxlKTtcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0RGl2LmFwcGVuZENoaWxkKGxpbmtVcmwpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIG9uIGNsaWNrIGxpc3RlbmVyXHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdERpdi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLmRvd25sb2Fkcy5vcGVuKGZpbGUuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIG9wZW4gaW4gZmlsZSBleHBsb3JlciBidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBsZXQgbW9yZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpO1xyXG4gICAgICAgICAgICAgICAgICAgIG1vcmUuaWQgPSAnbW9yZV9pY29uJztcclxuICAgICAgICAgICAgICAgICAgICBtb3JlLnNyYyA9ICcuLi8uLi9hc3NldHMvTW9yZS5wbmcnO1xyXG4gICAgICAgICAgICAgICAgICAgIG1vcmUuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS5kb3dubG9hZHMuc2hvdyhmaWxlLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICByaWdodERpdi5hcHBlbmRDaGlsZChtb3JlKTtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlSXRlbS5hcHBlbmRDaGlsZChsZWZ0RGl2KTtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlSXRlbS5hcHBlbmRDaGlsZChyaWdodERpdik7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZUVsZW1lbnQuYXBwZW5kQ2hpbGQoZmlsZUl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYFtJTkZPXSBza2lwcGVkIGR1cGxpY2F0ZSBmaWxlOiAke2ZpbGUuZmlsZW5hbWV9LmApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coYFtJTkZPXSAke2xvY2FsUGRmQ291bnR9IGxvY2FsIFBERnMgZm91bmQuYCk7XHJcbiAgICAgICAgdXBkYXRlRm9vdGVyKCk7XHJcbiAgICB9KTtcclxufVxyXG5mdW5jdGlvbiB1cGRhdGVGb290ZXIoKSB7XHJcbiAgICBpZiAoY3VycmVudFRhYiA9PSBUYWIuTG9jYWwpIHtcclxuICAgICAgICBsb2NhbEZvb3Rlcihsb2NhbFBkZkNvdW50KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIG9ubGluZUZvb3RlcihvbmxpbmVQZGZDb3VudCk7XHJcbiAgICB9XHJcbn1cclxuLy8gbG9hZCBhbmQgY3JlYXRlIHRoZSBvbmxpbmUgcGRmIGZvb3RlclxyXG5mdW5jdGlvbiBvbmxpbmVGb290ZXIoY291bnQpIHtcclxuICAgIGxldCBwbHVyYWwgPSBjb3VudCA+IDEgPyAncycgOiAnJztcclxuICAgIGxldCBjb3VudERpc3BsYXkgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY291bnQtZGlzcGxheScpO1xyXG4gICAgY291bnREaXNwbGF5LmlubmVySFRNTCA9IGBTaG93aW5nICR7Y291bnR9IG9ubGluZSBQREYke3BsdXJhbH0uYDtcclxufVxyXG4vLyBsb2FkIGFuZCBjcmVhdGUgdGhlIGxvY2FsIGZpbGUgZm9vdGVyXHJcbmZ1bmN0aW9uIGxvY2FsRm9vdGVyKGNvdW50KSB7XHJcbiAgICBsZXQgcGx1cmFsID0gY291bnQgPiAxID8gJ3MnIDogJyc7XHJcbiAgICBsZXQgY291bnREaXNwbGF5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2NvdW50LWRpc3BsYXknKTtcclxuICAgIGNvdW50RGlzcGxheS5pbm5lckhUTUwgPSBgU2hvd2luZyAke2NvdW50fSBsb2NhbCBQREYke3BsdXJhbH0uYDtcclxufVxyXG4vLyBmdW5jdGlvbiB0aGF0IGhhbmRsZXMgc3dpdGNoaW5nIGJldHdlZW4gdGFic1xyXG5mdW5jdGlvbiBvcGVuVGFiKGV2dCwgdGFiKSB7XHJcbiAgICAvLyBGaW5kIGFjdGl2ZSBlbGVtZW50cyBhbmQgcmVtb3ZlIGFjdGl2ZSBjbGFzcyBmcm9tIGVsZW1lbnRzXHJcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5hY3RpdmUnKTtcclxuICAgIGFjdGl2ZUVsZW1lbnRzLmZvckVhY2goZnVuY3Rpb24gKGVsZW0pIHtcclxuICAgICAgICBlbGVtLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpO1xyXG4gICAgfSk7XHJcbiAgICAvLyBBZGQgYWN0aXZlIGNsYXNzIHRvIHRhYiBhbmQgcHJlc3NlZCBidXR0b25cclxuICAgIGNvbnN0IHRhYkNvbnRlbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGAudGFiY29udGVudCMke3RhYn1gKTtcclxuICAgIGlmICh0YWJDb250ZW50KSB7XHJcbiAgICAgICAgdGFiQ29udGVudC5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcclxuICAgIH1cclxuICAgIGV2dC5jdXJyZW50VGFyZ2V0LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgY3VycmVudFRhYiA9IHRhYjtcclxufVxyXG5mdW5jdGlvbiBnZXRPcHRpb24obmFtZSwgY2FsbGJhY2spIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XHJcbiAgICAgICAgcmV0dXJuIHlpZWxkIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtuYW1lXSwgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZ2V0T3B0aW9uJywgcmVzdWx0KTtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrKHJlc3VsdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmZ1bmN0aW9uIGxvYWRPcHRpb25zKCkge1xyXG4gICAgZ2V0T3B0aW9uKCdnZW5lcmFsLmRlZmF1bHRUYWInLCAocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRUYWIgPSByZXN1bHRbJ2dlbmVyYWwuZGVmYXVsdFRhYiddO1xyXG4gICAgICAgIGlmIChkZWZhdWx0VGFiKSB7XHJcbiAgICAgICAgICAgIGlmIChkZWZhdWx0VGFiID09ICdPbmxpbmUgZmlsZXMnKSB7XHJcbiAgICAgICAgICAgICAgICBvbmxpbmVUYWJMaW5rLmNsaWNrKCk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnY2xpY2tlZCBvbmxpbmUgdGFiIGxpbmsnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChkZWZhdWx0VGFiID09ICdMb2NhbCBmaWxlcycpIHtcclxuICAgICAgICAgICAgICAgIGxvY2FsVGFiTGluay5jbGljaygpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NsaWNrZWQgbG9jYWwgdGFiIGxpbmsnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxvY2FsVGFiTGluay5jbGljaygpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2xvYWRlZCBkZWZhdWx0cycpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBsb2NhbFRhYkxpbmsuY2xpY2soKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG5sb2FkT3B0aW9ucygpO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9