interface WebExt {
  browser: typeof chrome;
}

interface Window extends WebExt {}
