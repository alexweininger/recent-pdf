/*
Alex Weininger
*/

var maxResults = 1000; // number of pages to search

let localCount = 0;
let onlineCount = 0;
searchHistory(maxResults);

let onlineFooter = document.getElementById('online-footer');

let footerElement = document.createElement('p');

function searchHistory(maxResults) {
    chrome.history.search({
        text: '.pdf',
        maxResults: maxResults
    }, function (data) {
        localCount = 0;
        onlineCount = 0;
        data.forEach(function (page) {

            var maxUrlLength = 30;
            var element = document.getElementById("link-list");
            var fileElement = document.getElementById('file-list');

            if (page.url.endsWith(".pdf")) { // check if page is a .pdf

                var trimmedUrl = trimUrl(page.url, maxUrlLength); // trim the url to make user-readable 

                var listItem = document.createElement("li");

                listItem.classList.add('list-item');
                var wrapper = document.createElement("div");

                wrapper.className = "li-wrapper";

                if (page.url.startsWith("file:")) {
                    localCount++;

                    let stringId = 'url-text-' + localCount;
                    listItem.innerHTML = "<p class='file-title'> Local file - click to select url </p><p id='" + stringId + "' class='file-url'>" + trimmedUrl + "</p>";

                    listItem.addEventListener("click", function () {
                        selectText(stringId);
                    });
                    wrapper.appendChild(listItem);
                    fileElement.appendChild(wrapper);
                } else {

                    let linkTitle = lastStr(page.url);
                    let linkDetailed = decodeURI(page.url).substring(0, 50).replace(' ', '');

                    onlineCount++;

                    let link = document.createElement('a');

                    link.href = page.url;
                    link.classList.add('a');
                    link.target = '_blank';

                    let title = document.createElement('p');
                    title.classList.add('link-title');
                    title.innerText = lastStr(page.url);

                    let linkUrl = document.createElement('p');
                    linkUrl.classList.add('link-url');
                    linkUrl.innerHTML = decodeURI(page.url).substring(0, 50).replace(' ', '');

                    let icon = document.createElement('img');
                    icon.classList.add('link-thumb');
                    icon.src = 'chrome://favicon/' + page.url;

                    link.appendChild(icon);
                    link.appendChild(title);
                    link.appendChild(linkUrl);

                    let strLinkTitle = "<p class='link-title'>" + lastStr(page.url) + "</p>";
                    let strLink = "<p class='link-url'>" + decodeURI(page.url).substring(0, 50).replace(' ', '') + "</p>";
                    let strIcon = "<img class='link-thumb' src='chrome://favicon/" + page.url + "'>";

                    let strA = "<a target='_blank' class='a' href='" + page.url + "'>" + strIcon + " " + strLinkTitle + strLink + "</a>";

                    listItem.innerHTML = strA;

                    console.log(link);
                    wrapper.appendChild(link);

                    element.appendChild(wrapper);
                }
            }
        });
        console.log(onlineCount);
        footerElement.innerText = footerStr(onlineCount);
        onlineFooter.appendChild(footerElement);
    });
}

function footerStr(count) {
    if (count > 1) {
        return 'Showing ' + onlineCount + ' PDFs on 1 page.';
    } else {
        return 'Showing ' + onlineCount + ' PDF on 1 page.'
    }
}

function lastStr(url) {
    url = decodeURI(url);
    url = url.substring(url.lastIndexOf('/') + 1, url.length - 4)
    return url;
}

function trimUrl(url, maxUrlLength) {
    url = decodeURI(url);
    var urlPrefix = "";

    if (url.startsWith("file:")) {
        urlPrefix = "file:";
    }

    var url = url.substring(5);

    if (url.length > maxUrlLength) {
        url = url.substring(url.lastIndexOf('/'), url.length);
    }

    if (url.length > maxUrlLength) {
        url = url.substring(url.length - maxUrlLength, url.length);
    }
    url = url.substring(0, url.length - 4);

    return urlPrefix + url;
}

function selectText(node) {
    console.log(node);
    node = document.getElementById(node);

    if (document.body.createTextRange) {
        const range = document.body.createTextRange();
        range.moveToElementText(node);
        range.select();
    } else if (window.getSelection) {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(node);
        selection.removeAllRanges();
        selection.addRange(range);
    } else {
        console.warn("Could not select text in node: Unsupported browser.");
    }
}

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

let onlineTabLink = document.getElementById('online-tab-link');
let localTabLink = document.getElementById('local-tab-link');
let settingsTabLink = document.getElementById('settings-tab-link');



onlineTabLink.addEventListener('click', function () {
    openTab(event, 'online');
});

localTabLink.addEventListener('click', function () {
    openTab(event, 'local');
});

settingsTabLink.addEventListener('click', function () {
    openTab(event, 'settings');
});

onlineTabLink.click();